import json
import pandas as pd
import pickle
import os
import re
import numpy as np
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score


DATA_PATH = "your_data_path"
JSON_FILE = "multi_turn_hate_detection_results.json"


def extract_label_from_raw_response(raw_response):

    try:

        label_match = re.search(r'"label":\s*([01])', raw_response)
        if label_match:
            return int(label_match.group(1))
    except:
        pass
    return None


def extract_predictions_from_json(json_file):

    with open(json_file, 'r', encoding='utf-8') as f:
        data = json.load(f)

    predictions_dict = {}


    if isinstance(data, list):
        video_data_list = data
    else:
        video_data_list = [data]

    for video_data in video_data_list:
        try:
            video_id = video_data['video_id']


            if 'multi_turn_results' not in video_data or video_data['multi_turn_results'] is None:
                print(f"Skip {video_id}: multi_turn_results not found")
                continue


            if 'turn_4' not in video_data['multi_turn_results'] or video_data['multi_turn_results']['turn_4'] is None:
                print(f"Skip {video_id}: turn_4 not found")
                continue

            turn_4_data = video_data['multi_turn_results']['turn_4']


            if 'parsed_response' in turn_4_data and turn_4_data['parsed_response']:
                try:
                    final_label = turn_4_data['parsed_response']['final_decision']['label']
                except (KeyError, TypeError):
                    raw_response = turn_4_data.get('raw_response', '')
                    final_label = extract_label_from_raw_response(raw_response)
            else:
                raw_response = turn_4_data.get('raw_response', '')
                final_label = extract_label_from_raw_response(raw_response)

            if final_label is not None:
                predictions_dict[video_id] = final_label
            else:
                print(f"Skip {video_id}")

        except Exception as e:
            print(f" {video_data.get('video_id', 'unknown')} error: {e}")
            continue

    return predictions_dict


def calculate_fold_metrics(test_ids, test_y, predictions_dict):

    y_true = []
    y_pred = []

    for video_id, true_label in zip(test_ids, test_y):
        if video_id in predictions_dict:
            y_true.append(true_label)
            y_pred.append(predictions_dict[video_id])

    if len(y_true) == 0:

        return None


    accuracy = accuracy_score(y_true, y_pred)
    macro_f1 = f1_score(y_true, y_pred, average='macro')
    f1_positive = f1_score(y_true, y_pred, pos_label=1, zero_division=0)
    precision_positive = precision_score(y_true, y_pred, pos_label=1, zero_division=0)
    recall_positive = recall_score(y_true, y_pred, pos_label=1, zero_division=0)

    return {
        'accuracy': accuracy,
        'macro_f1': macro_f1,
        'f1_positive': f1_positive,
        'precision_positive': precision_positive,
        'recall_positive': recall_positive,
        'n_samples': len(y_true),
        'n_total_test': len(test_ids)
    }


def five_fold_evaluation(json_file, data_path):

    with open(os.path.join(data_path, "five_fold_MHC.pkl"), "rb") as f:
        folds = pickle.load(f)


    predictions_dict = extract_predictions_from_json(json_file)


    fold_results = []

    for fid in range(1, 6):
        print(f"\n===== Fold {fid} =====")

        train_ids, train_y = folds[f"Fold_{fid}"]["train"]
        val_ids, val_y = folds[f"Fold_{fid}"]["val"]
        test_ids, test_y = folds[f"Fold_{fid}"]["test"]

        print(f"Test set number: {len(test_ids)}")


        metrics = calculate_fold_metrics(test_ids, test_y, predictions_dict)

        if metrics is not None:
            fold_results.append(metrics)


            print(f"Accuracy: {metrics['accuracy']:.4f}")
            print(f"Macro F1: {metrics['macro_f1']:.4f}")
            print(f"F1 (Positive): {metrics['f1_positive']:.4f}")
            print(f"Precision (Positive): {metrics['precision_positive']:.4f}")
            print(f"Recall (Positive): {metrics['recall_positive']:.4f}")
        else:
            print("Can not process")


    if fold_results:
        print("\n" + "=" * 50)
        print("Five-Fold Cross Validation")
        print("=" * 50)

        metrics_names = ['accuracy', 'macro_f1', 'f1_positive', 'precision_positive', 'recall_positive']
        avg_metrics = {}
        std_metrics = {}

        for metric in metrics_names:
            values = [fold[metric] for fold in fold_results]
            avg_metrics[metric] = np.mean(values)
            std_metrics[metric] = np.std(values)

            print(f"{metric.capitalize().replace('_', ' ')}: {avg_metrics[metric]:.4f} ± {std_metrics[metric]:.4f}")


        total_samples = sum(fold['n_samples'] for fold in fold_results)
        total_test = sum(fold['n_total_test'] for fold in fold_results)



        detailed_results = {
            'fold_results': fold_results,
            'average_metrics': avg_metrics,
            'std_metrics': std_metrics,
            'total_samples': total_samples,
            'total_test_samples': total_test
        }


        with open('five_fold_evaluation_results.json', 'w', encoding='utf-8') as f:
            json.dump(detailed_results, f, indent=2, ensure_ascii=False)

        print(f"\nDetailed results have been saved to: five_fold_evaluation_results.json")

        return detailed_results
    else:

        return None



if __name__ == "__main__":

    json_file = "# Replace with the path to your JSON file"
    data_path = "# Replace with the path containing five_folds.pickle"


    results = five_fold_evaluation(json_file, data_path)